import javax.swing.JMenuItem;
import jpcap.*;
public class Main {
    public static void main(String[] args) {
        new UserInterface();
    }
}